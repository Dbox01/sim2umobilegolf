import type { AddOn } from './packages'

/**
 * ============================================================
 *  ADD-ONS THAT ARE NOT AGREED YET.
 * ============================================================
 *
 * NOTHING IMPORTS THIS FILE, AND THAT IS THE POINT. Vite only bundles what
 * is reachable from a page, so an unagreed price parked here never reaches
 * the browser. It is still type-checked and still reviewable in the repo.
 *
 * ------------------------------------------------------------
 *  TO PUT ONE LIVE
 * ------------------------------------------------------------
 *  1. Replace every PLACEHOLDER below with the agreed wording and figure.
 *  2. Move the whole object into ADD_ONS in packages.ts.
 *  3. Delete it from here.
 *
 * Do not shortcut step 3 by importing this file. A draft that is imported
 * is no longer a draft — it is a published price with a comment above it.
 */

export const DRAFT_ADD_ONS: AddOn[] = [
  {
    /* ----------------------------------------------------------------
     *  EVENT PHOTOGRAPHY — partnership with RuNic Studios.
     * ----------------------------------------------------------------
     *  Still to agree with them before this goes live:
     *
     *   · The price, or a genuine "From R…"
     *   · How long the photographer is on site — the whole booking, or a
     *     set number of hours?
     *   · How many edited images the client receives
     *   · Turnaround: how long after the event the images arrive
     *   · Usage rights — can the client use them commercially, and can
     *     Sim2U use them on this website and on social?
     *   · Whether RuNic Studios is named here. Their site describes them as
     *     a "Brand Strategy & Social Media Agency" and does not advertise
     *     event photography, so how they want to be credited for this is
     *     their call as much as ours. The copy below says "our photography
     *     partner" so it reads correctly either way until that is settled.
     *   · Who invoices the client — Sim2U passing it through, or RuNic
     *     directly. This changes what the service agreement has to say.
     */
    name: 'Event Photography',
    icon: 'camera',
    price: 'PLACEHOLDER — price to confirm',
    /* Short on purpose. The partner band above it already says who is behind
       this, so the copy only has to say what the client gets. The other two
       add-ons can afford a paragraph; this card is carrying a logo and needs
       the room. */
    detail:
      'A professional photographer while the simulator runs. Edited images afterwards, yours to use.',
    partner: {
      name: 'RuNic Studios',
      /* Their own colours, read off runicstudios.co.za: the blush-to-
         periwinkle gradient from their hero, with their indigo and a deepened
         rose for the text. Used as a band across the top of the card, not as
         the card's background — a card repainted end to end in a partner's
         palette reads as an advert pasted into the page.

         Both ink colours were checked against all three gradient stops:
         indigo clears 6.8:1 at worst, the rose 6.1:1. If you change a stop,
         re-check them — pale gradients hide unreadable text very well. */
      theme: {
        /* Their indigo, solid across the banner — the loud bit. */
        band: '#374375',
        bandInk: '#FFFFFF',
        /* Their hero gradient, lightened so dark text clears 4.5:1 on it. */
        from: '#F7E6DF',
        via: '#FFFCF5',
        to: '#E3E6F5',
        /* Gold would sit at 2:1 on that gradient, grey body text at 3.9:1.
           These replace them: 7.0:1 and 6.1:1 respectively. */
        accent: '#6E3F46',
        body: '#4A5568',
      },
      /* logo: '/partners/runic-studios.png'
         Add once they supply the file. Drop it in public/partners/ — self
         hosted, never hotlinked from their site. Roughly 400px square, PNG
         with a transparent background. Until this line exists the card shows
         a marked placeholder rather than a broken image. */
    },
  },
]
