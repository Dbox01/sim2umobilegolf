import type { AddOn } from './packages'

/**
 * ============================================================
 *  ADD-ONS THAT ARE NOT AGREED YET.
 * ============================================================
 *
 * NOTHING IMPORTS THIS FILE, AND THAT IS THE POINT. Vite only bundles what
 * is reachable from a page, so an unagreed price parked here never reaches
 * the browser. It is still type-checked and still reviewable in the repo.
 *
 * ------------------------------------------------------------
 *  TO PUT ONE LIVE
 * ------------------------------------------------------------
 *  1. Replace every PLACEHOLDER below with the agreed wording and figure.
 *  2. Move the whole object into ADD_ONS in packages.ts.
 *  3. Delete it from here.
 *
 * Do not shortcut step 3 by importing this file. A draft that is imported
 * is no longer a draft — it is a published price with a comment above it.
 */

export const DRAFT_ADD_ONS: AddOn[] = [
  {
    /* ----------------------------------------------------------------
     *  EVENT PHOTOGRAPHY — partnership with RuNic Studios.
     * ----------------------------------------------------------------
     *  SETTLED (Dylan, 23 Sep): R900 per hour, and that rate covers every
     *  photo taken and all the editing — no per-image charge on top.
     *
     *  STILL OPEN before this goes live:
     *
     *   · Is there a minimum? Most photographers will not book a single
     *     hour. If theirs is 2 or 3, the card has to say so — a client who
     *     reads "R900/hour" and budgets for one hour will be annoyed at the
     *     quote, which is the opposite of what an add-on card is for.
     *   · Does the photographer stay for the whole booking, or a block the
     *     client picks? On a 6-hour outdoor event the difference is R5,400
     *     against maybe R1,800, so the card cannot leave this to guesswork.
     *   · Turnaround: how long after the event the images arrive.
     *   · Usage rights. "Includes all photos and editing" is about delivery,
     *     not licence, so the copy below deliberately does NOT say the
     *     images are the client's to use commercially. Add that line once
     *     RuNic confirms it — and separately, whether Sim2U may use the
     *     images on this site and on social.
     *   · Whether RuNic Studios is named here. Their site describes them as
     *     a "Brand Strategy & Social Media Agency" and does not advertise
     *     event photography, so how they want to be credited for this is
     *     their call as much as ours.
     *   · Who invoices the client — Sim2U passing it through, or RuNic
     *     directly. This changes what the service agreement has to say.
     */
    name: 'Event Photography',
    icon: 'camera',
    /* Matches the hand-written format of the other two add-ons ("From
       R1,300", "R2,000") rather than formatRand, which puts a space after
       the R. */
    price: 'R900 / hour',
    /* Short on purpose. The partner band above it already says who is behind
       this, so the copy only has to say what the client gets. The other two
       add-ons can afford a paragraph; this card is carrying a logo and needs
       the room.

       "Nothing extra per photo" is the line worth having: an hourly rate
       invites the reader to assume image packages and print fees are coming,
       and this one genuinely does not have them. */
    detail:
      'A professional photographer on site while the simulator runs. Every image edited and delivered afterwards — nothing extra per photo.',
    partner: {
      name: 'RuNic Studios',
      /* Their own colours, read off runicstudios.co.za: the blush-to-
         periwinkle gradient from their hero, with their indigo and a deepened
         rose for the text. Used as a band across the top of the card, not as
         the card's background — a card repainted end to end in a partner's
         palette reads as an advert pasted into the page.

         Both ink colours were checked against all three gradient stops:
         indigo clears 6.8:1 at worst, the rose 6.1:1. If you change a stop,
         re-check them — pale gradients hide unreadable text very well. */
      theme: {
        /* Their indigo, solid across the banner — the loud bit. */
        band: '#374375',
        bandInk: '#FFFFFF',
        /* Their hero gradient, lightened so dark text clears 4.5:1 on it. */
        from: '#F7E6DF',
        via: '#FFFCF5',
        to: '#E3E6F5',
        /* Gold would sit at 2:1 on that gradient, grey body text at 3.9:1.
           These replace them: 7.0:1 and 6.1:1 respectively. */
        accent: '#6E3F46',
        body: '#4A5568',
      },
      /* Their file, self-hosted in public/partners/ — never hotlinked from
         their site. Supplied as a 1000px PNG with a transparent background;
         cropped to the monogram and resampled to 400px square.

         It is their pale variant (#FFFCF5), the one meant for dark grounds,
         which is why logoInk says 'light'. On the white chip the card gives a
         dark logo it disappears completely; on the indigo band it measures
         9.2:1, well clear of the 3:1 a graphic needs. If they ever send a
         dark-on-light file, switch this to 'dark'
         and the chip comes back. */
      logo: '/partners/runic-studios.png',
      logoInk: 'light',
    },
  },
]
